#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include "Core.h"
#include "String_.h"
#include "Chat.h"
#include "Commands.h"
#include "Event.h"
#include "Logger.h"
#include "Options.h"
#include "Platform.h"
#include "Server.h"
#include "World.h"

#define CRASH_QUIT_CMD "/quit"

#ifdef _WIN32
extern void CrashWin_Install(void (*cb)(const char* reason));
#endif

static cc_bool crash_inGame, crash_done;

static void Crash_MapLoaded(void* obj) { crash_inGame = true; }

static void Crash_WriteLog(const char* reason, const char* detail) {
        FILE* f;
        time_t now;
        struct tm* t;
        char datebuf[32] = "0000-00-00 00:00:00";

        time(&now);
        t = localtime(&now);
        if (t) strftime(datebuf, sizeof(datebuf), "%Y-%m-%d %H:%M:%S", t);

        f = fopen("classiemicx_crash.log", "a");
        if (!f) return;
        fprintf(f, "[%s] MOTIVO: %s | DETALLE: %s\n", datebuf, reason, detail ? detail : "N/A");
        fclose(f);
}

static void Crash_Handle(const char* reason, const char* detail) {
        cc_string msg; char buf[STRING_SIZE];
        if (crash_done) return;
        crash_done = true;

        Crash_WriteLog(reason, detail);

        if (!crash_inGame || Server.IsSinglePlayer || !Options_GetBool("crash-notify", true)) return;
        String_InitArray(msg, buf);
        String_AppendConst(&msg, CRASH_QUIT_CMD " ClassiEmicx: ERROR FATAL, ");
        String_AppendConst(&msg, reason);
        Chat_Send(&msg, false);
        Thread_Sleep(250);
}

static void Crash_NotifyWin(const char* reason) {
        Crash_Handle(reason, "Excepcion nativa de Windows / SIGABRT");
}

static cc_bool Crash_Has(const char* s, const char* needle) {
        int i, j, n = (int)strlen(needle);
        for (i = 0; s[i]; i++) {
                for (j = 0; j < n; j++) {
                        if (!s[i + j] || tolower((unsigned char)s[i + j]) != needle[j]) break;
                }
                if (j == n) return true;
        }
        return false;
}

static void Crash_NotifyFromMessage(const char* raw_msg) {
        char reason[40];
        int i, o = 0;
        unsigned char c;

        if (!raw_msg || !raw_msg[0]) {
                strcpy(reason, "ERROR_DESCONOCIDO");
        } else if (Crash_Has(raw_msg, "memory") || Crash_Has(raw_msg, "alloc")) {
                strcpy(reason, "OUT_OF_MEMORY");
        } else {
                for (i = 0; raw_msg[i] && o < (int)sizeof(reason) - 1; i++) {
                        c = (unsigned char)raw_msg[i];
                        if (isalnum(c))                        reason[o++] = (char)toupper(c);
                        else if (o > 0 && reason[o - 1] != '_') reason[o++] = '_';
                }
                while (o > 0 && reason[o - 1] == '_') o--;
                reason[o] = '\0';
                if (!o) strcpy(reason, "ERROR_DESCONOCIDO");
        }
        Crash_Handle(reason, raw_msg);
}

extern void __real_Logger_DoAbort(cc_result result, const char* raw_msg, void* ctx);
void __wrap_Logger_DoAbort(cc_result result, const char* raw_msg, void* ctx) {
        Crash_NotifyFromMessage(raw_msg);
        __real_Logger_DoAbort(result, raw_msg, ctx);
}

extern void __real_Process_Abort2(cc_result result, const char* raw_msg);
void __wrap_Process_Abort2(cc_result result, const char* raw_msg) {
        Crash_NotifyFromMessage(raw_msg);
        __real_Process_Abort2(result, raw_msg);
}

static void CrashTest_Execute(const cc_string* args, int argsCount) {
        if (!Options_GetBool("crash-test", false)) { Chat_AddRaw("&ePon crash-test=True en options.txt para probar."); return; }
        if (String_CaselessEqualsConst(args, "memoria"))     Process_Abort2(0, "Out of memory (prueba)");
        else if (String_CaselessEqualsConst(args, "acceso")) *(volatile int*)0 = 1;
        else Chat_AddRaw("&eUso: /client crashtest memoria | acceso");
}

static struct ChatCommand CrashTestCommand = {
        "CrashTest", CrashTest_Execute, COMMAND_FLAG_UNSPLIT_ARGS,
        {
                "&a/client crashtest memoria | acceso",
                "&eProvoca un error fatal a proposito (solo con crash-test=True)."
        }
};

void CrashCmd_Register(void) {
        Event_Register_(&WorldEvents.MapLoaded, NULL, Crash_MapLoaded);
#ifdef _WIN32
        CrashWin_Install(Crash_NotifyWin);
#endif
        Commands_Register(&CrashTestCommand);
}
