#ifndef GROQAUTH_H
#define GROQAUTH_H
extern char AI_ApiKey[256];
#include <string.h>
#include <stdlib.h>
static cc_bool Groq_IsReq(const struct HttpRequest* req) {
	return strncmp(req->url, "https://api.groq.com/", 21) == 0;
}
static void Groq_AddAuth(const struct HttpRequest* req, cc_string* dst) {
	const char* key;
	if (!Groq_IsReq(req)) return;
	key = AI_ApiKey;
	if (key && key[0]) String_Format1(dst, "Authorization: Bearer %c\r\n", key);
}
#endif
