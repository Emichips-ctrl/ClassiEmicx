#include "Core.h"
#include "String_.h"
#include "Chat.h"
#include "Commands.h"
#include "Platform.h"

#define FEEDBACK_URL "https://forms.gle/B7tXdCLGfvapVHTd6"

static void FeedbackCmd_Execute(const cc_string* args, int argsCount) {
	static const cc_string url = String_FromConst(FEEDBACK_URL);
	cc_result res;

	if (String_CaselessEqualsConst(args, "abrir")) {
		if (!Process_OpenSupported) { Chat_AddRaw("&cEsta plataforma no puede abrir el navegador."); return; }
		res = Process_StartOpen(&url);
		Chat_AddRaw(res ? "&cNo pude abrir el navegador."
		                : "&aAbriendo el formulario en tu navegador...");
		return;
	}
	Chat_AddRaw("&eDanos tu opinion sobre ClassiEmicx:");
	Chat_AddRaw(FEEDBACK_URL);
	Chat_AddRaw("&7(pulsa el enlace con el chat abierto, o /client feedback abrir)");
}

static struct ChatCommand FeedbackCommand = {
	"Feedback", FeedbackCmd_Execute, COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client feedback",
		"&eMuestra el enlace para dar tu opinion del cliente.",
		"&e/client feedback abrir: lo abre en el navegador."
	}
};

void FeedbackCmd_Register(void) { Commands_Register(&FeedbackCommand); }
