#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <signal.h>

static LPTOP_LEVEL_EXCEPTION_FILTER crashwin_prev;
static void (*crashwin_cb)(const char* reason);
static volatile LONG crashwin_busy;

static const char* CrashWin_Name(DWORD code, char* buf, int cap) {
        switch (code) {
        case 0xC0000005: return "ACCESS_VIOLATION";
        case 0xC00000FD: return "STACK_OVERFLOW";
        case 0xC000001D: return "ILLEGAL_INSTRUCTION";
        case 0xC0000094: return "DIVISION_POR_CERO";
        case 0xC0000017: return "OUT_OF_MEMORY";
        case 0xC0000374: return "HEAP_CORRUPTION";
        }
        _snprintf(buf, cap, "EXCEPCION_%08lX", (unsigned long)code);
        buf[cap - 1] = '\0';
        return buf;
}

static LONG WINAPI CrashWin_Filter(EXCEPTION_POINTERS* info) {
        char buf[32];
        if (crashwin_cb && info && info->ExceptionRecord && !InterlockedExchange(&crashwin_busy, 1)) {
                crashwin_cb(CrashWin_Name(info->ExceptionRecord->ExceptionCode, buf, sizeof(buf)));
        }
        return crashwin_prev ? crashwin_prev(info) : EXCEPTION_CONTINUE_SEARCH;
}

static void CrashWin_OnAbort(int sig) {
        if (crashwin_cb && !InterlockedExchange(&crashwin_busy, 1)) crashwin_cb("ABORT");
        signal(SIGABRT, SIG_DFL);
        raise(SIGABRT);
}

void CrashWin_Install(void (*cb)(const char* reason)) {
        crashwin_cb   = cb;
        crashwin_prev = SetUnhandledExceptionFilter(CrashWin_Filter);
        signal(SIGABRT, CrashWin_OnAbort);
}
#endif
