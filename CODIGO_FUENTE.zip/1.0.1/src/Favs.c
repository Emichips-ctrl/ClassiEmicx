#include <string.h>
#include "Core.h"
#include "String_.h"
#include "Options.h"

cc_bool Launcher_FavsOnly;

static int Favs_Key(const cc_string* hash, char* key, int cap) {
	int i;
	char c;
	if (!hash->length || hash->length > 64 || cap < hash->length + 8) return 0;
	strcpy(key, "fav-");
	for (i = 0; i < hash->length; i++) {
		c = hash->buffer[i];
		if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))) return 0;
		key[4 + i] = c;
	}
	key[4 + hash->length] = '\0';
	return 1;
}

cc_bool Favs_Has(const cc_string* hash) {
	char key[80];
	return Favs_Key(hash, key, (int)sizeof(key)) && Options_GetBool(key, false);
}

void Favs_Toggle(const cc_string* hash) {
	char key[80];
	if (!Favs_Key(hash, key, (int)sizeof(key))) return;
	Options_SetBool(key, !Options_GetBool(key, false));
}

cc_bool Favs_Pass(const cc_string* hash) {
	return !Launcher_FavsOnly || Favs_Has(hash);
}
