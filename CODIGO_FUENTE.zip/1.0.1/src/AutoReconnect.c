#include "String_.h"
#include "Commands.h"
#include "Chat.h"
#include "Core.h"
#include "Event.h"
#include "Game.h"
#include "Gui.h"
#include "Options.h"
#include "Server.h"
#include "World.h"

#define AR_MAX_ATTEMPTS 5
static int ar_attempts;
static cc_bool ar_pending, ar_taskAdded;
static struct Screen* ar_screen;

static void AutoReconnect_Reset(void* obj) { ar_attempts = 0; }

static void AutoReconnect_Tick(struct ScheduledTask* task) {
	struct Screen* s = ar_screen;
	if (!ar_pending) return;
	ar_pending = false;
	ar_screen  = NULL;
	if (!s) return;

	ar_attempts++;
	Gui_Remove(s);
	Gui_ShowDefault();
	Server.BeginConnect();
}

void AutoReconnect_Check(float delayLeft, struct Screen* s) {
	if (!ar_taskAdded) {
		ar_taskAdded = true;
		Event_Register_(&WorldEvents.MapLoaded, NULL, AutoReconnect_Reset);
		ScheduledTask_Add(0.5, AutoReconnect_Tick);
	}
	if (delayLeft > 0 || ar_pending) return;
	if (Server.IsSinglePlayer) return;
	if (!Options_GetBool("auto-reconnect", true)) return;
	if (ar_attempts >= AR_MAX_ATTEMPTS) return;

	ar_pending = true;
	ar_screen  = s;
}

static void AutoReconnectCmd_Execute(const cc_string* args, int argsCount) {
	cc_bool on = Options_GetBool("auto-reconnect", true);

	if (String_CaselessEqualsConst(args, "on"))       on = true;
	else if (String_CaselessEqualsConst(args, "off")) on = false;
	else if (!args->length)                           on = !on;
	else { Chat_AddRaw("&eUso: /client autoreconnect [on|off]"); return; }

	Options_SetBool("auto-reconnect", on);
	ar_attempts = 0;
	Chat_AddRaw(on ? "&eAuto-reconexion: &aACTIVADA" : "&eAuto-reconexion: &cDESACTIVADA");
}

static struct ChatCommand AutoReconnectCmd = {
	"AutoReconnect", AutoReconnectCmd_Execute, COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client autoreconnect [on|off]",
		"&eActiva o desactiva la reconexion automatica.",
		"&eSin argumentos, cambia el estado actual."
	}
};

void AutoReconnectCmd_Register(void) { Commands_Register(&AutoReconnectCmd); }
