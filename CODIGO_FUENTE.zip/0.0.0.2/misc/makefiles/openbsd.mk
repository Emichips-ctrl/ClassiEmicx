SOURCE_DIRS := src third_party/bearssl
BUILD_DIR	:= build/openbsd
TARGET 		:= ClassiCube
DIST_NAME	:= ClassiCube

CFLAGS	:= -I /usr/X11R6/include -I /usr/local/include -fvisibility=hidden -fno-ident
LDFLAGS := -L /usr/X11R6/lib -L /usr/local/lib -rdynamic
LIBS    := -lexecinfo -lGL -lX11 -lXi -lpthread
include misc/makefiles/common_config.mk


#---------------------------------------------------------------------------------
# executable generation
#---------------------------------------------------------------------------------
include misc/makefiles/common_build.mk


#---------------------------------------------------------------------------------
# common targets
#---------------------------------------------------------------------------------
include misc/makefiles/common_targets.mk

dist: $(TARGET)
	$(call DIST_PKG_INIT_DEFAULT,$(TARGET))
	$(call DIST_PKG_BUILD_TAR,$(TARGET))
