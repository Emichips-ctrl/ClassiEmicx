#include <stdlib.h>
#include <string.h>
#include "Core.h"
#include "String_.h"
#include "Chat.h"
#include "Commands.h"
#include "Game.h"
#include "Http.h"
#include "Options.h"

#define AI_URL                 "https://api.groq.com/openai/v1/chat/completions"
#define AI_MODEL        "openai/gpt-oss-20b"
#define AI_SYSTEM_OPTION       "ai-system-prompt"
#define AI_SYSTEM_DEFAULT      "Eres el asistente de ClassiEmicx, un cliente de ClassiCube. Responde siempre en espanol, de forma breve (maximo 3 frases), sin emojis."
#define AI_SYSTEM_SIZE         2048
#define AI_MAX_HISTORY         50
#define AI_ENTRY_SIZE          2048
#define AI_BUDGET              7000
#define AI_BODY_SIZE           16384
#define AI_OUT_SIZE            4096
#define AI_LINE_MAX            54

struct AIEntry { cc_bool assistant; int len; char text[AI_ENTRY_SIZE]; };
static struct AIEntry ai_hist[AI_MAX_HISTORY];
static int ai_head, ai_count, ai_reqID;
static cc_bool ai_taskAdded;
static char ai_body[AI_BODY_SIZE];
static char ai_out[AI_OUT_SIZE];
static char ai_tmp[AI_ENTRY_SIZE * 2];
static char ai_system[AI_SYSTEM_SIZE];
static int  ai_systemLen;

/* Carga el prompt desde options.txt. Si no existe, crea la opcion predeterminada. */
static void AI_LoadSystemPrompt(void) {
	cc_string value, prompt;

	if (!Options_UNSAFE_Get(AI_SYSTEM_OPTION, &value)) {
		prompt = String_FromReadonly(AI_SYSTEM_DEFAULT);
		Options_Set(AI_SYSTEM_OPTION, &prompt);
		Options_SaveIfChanged();
	}

	String_InitArray(value, ai_system);
	Options_Get(AI_SYSTEM_OPTION, &value, AI_SYSTEM_DEFAULT);
	ai_systemLen = value.length;
}

static int AI_FromCP437(int c) {
	switch (c) {
	case 0xA0: return 0xE1; case 0x82: return 0xE9; case 0xA1: return 0xED;
	case 0xA2: return 0xF3; case 0xA3: return 0xFA; case 0xA4: return 0xF1;
	case 0xA5: return 0xD1; case 0x81: return 0xFC; case 0xA8: return 0xBF;
	case 0xAD: return 0xA1;
	}
	return '?';
}

static char AI_ToCP437(int cp) {
	switch (cp) {
	case 0xE1: return (char)0xA0; case 0xE9: return (char)0x82;
	case 0xED: return (char)0xA1; case 0xF3: return (char)0xA2;
	case 0xFA: return (char)0xA3; case 0xF1: return (char)0xA4;
	case 0xD1: return (char)0xA5; case 0xFC: return (char)0x81;
	case 0xBF: return (char)0xA8; case 0xA1: return (char)0xAD;
	case 0xC1: return 'A'; case 0xC9: return 'E'; case 0xCD: return 'I';
	case 0xD3: return 'O'; case 0xDA: return 'U';
	case 0x2018: case 0x2019: return '\'';
	case 0x201C: case 0x201D: return '"';
	case 0x2013: case 0x2014: return '-';
	case 0x2026: return '.';
	}
	if (cp < 128) return (char)cp;
	return '?';
}

static void AI_Escape(cc_string* dst, const cc_string* src) {
	static const char hex[] = "0123456789abcdef";
	int i, cp, s;
	for (i = 0; i < src->length; i++) {
		unsigned char c = (unsigned char)src->buffer[i];
		if (c == '"')        String_AppendConst(dst, "\\\"");
		else if (c == '\\')  String_AppendConst(dst, "\\\\");
		else if (c < 32)     String_Append(dst, ' ');
		else if (c < 127)    String_Append(dst, (char)c);
		else {
			cp = AI_FromCP437(c);
			String_AppendConst(dst, "\\u");
			for (s = 12; s >= 0; s -= 4) String_Append(dst, hex[(cp >> s) & 15]);
		}
	}
}

/* Recorta sin partir una secuencia de escape */
static int AI_SafeLen(const char* s, int len, int cap) {
	int i = 0, step;
	if (len <= cap) return len;
	while (i < cap) {
		step = 1;
		if (s[i] == '\\') step = (i + 1 < len && s[i + 1] == 'u') ? 6 : 2;
		if (i + step > cap) break;
		i += step;
	}
	return i;
}

static void AI_PushRaw(cc_bool assistant, const char* esc, int len) {
	struct AIEntry* e = &ai_hist[ai_head];
	len = AI_SafeLen(esc, len, AI_ENTRY_SIZE);
	memcpy(e->text, esc, len);
	e->len = len; e->assistant = assistant;
	ai_head = (ai_head + 1) % AI_MAX_HISTORY;
	if (ai_count < AI_MAX_HISTORY) ai_count++;
}

static void AI_PopLast(void) {
	if (!ai_count) return;
	ai_head = (ai_head + AI_MAX_HISTORY - 1) % AI_MAX_HISTORY;
	ai_count--;
}

static int AI_BuildBody(void) {
	cc_string body, system;
	int used = 0, include = 0, k, idx, budget;
	struct AIEntry* e;

	AI_LoadSystemPrompt();

	body = String_Init(ai_body, 0, AI_BODY_SIZE);
	String_AppendConst(&body, "{\"model\":\"" AI_MODEL "\",\"max_tokens\":1200,\"reasoning_effort\":\"low\",\"messages\":[");
	String_AppendConst(&body, "{\"role\":\"system\",\"content\":\"");

	system = String_Init(ai_system, ai_systemLen, AI_SYSTEM_SIZE);
	AI_Escape(&body, &system);
	String_AppendConst(&body, "\"}");

	/* Ajusta el presupuesto de historial al espacio que queda en el JSON. */
	budget = body.capacity - body.length - 64;
	if (budget > AI_BUDGET) budget = AI_BUDGET;
	if (budget < 0) budget = 0;

	/* Cuantos mensajes recientes caben en el presupuesto */
	for (k = 0; k < ai_count; k++) {
		idx = (ai_head - 1 - k + AI_MAX_HISTORY * 2) % AI_MAX_HISTORY;
		used += ai_hist[idx].len + 40;
		if (used > budget) break;
		include++;
	}
	/* No empezar con un mensaje del asistente */
	while (include > 1 && ai_hist[(ai_head - include + AI_MAX_HISTORY * 2) % AI_MAX_HISTORY].assistant) include--;

	for (k = include - 1; k >= 0; k--) {
		idx = (ai_head - 1 - k + AI_MAX_HISTORY * 2) % AI_MAX_HISTORY;
		e = &ai_hist[idx];
		String_AppendConst(&body, e->assistant ? ",{\"role\":\"assistant\",\"content\":\""
		                                       : ",{\"role\":\"user\",\"content\":\"");
		String_AppendAll(&body, e->text, e->len);
		String_AppendConst(&body, "\"}");
	}
	String_AppendConst(&body, "]}");
	return body.length;
}

static int AI_FindContent(const char* json, int len, int* start) {
	static const char key[] = "\"content\":\"";
	int i, j, s, e, klen = (int)sizeof(key) - 1;
	for (i = 0; i + klen <= len; i++) {
		for (j = 0; j < klen; j++) if (json[i + j] != key[j]) break;
		if (j != klen) continue;
		s = i + klen; e = s;
		while (e < len && json[e] != '"') { if (json[e] == '\\') e++; e++; }
		if (e > len) e = len;
		*start = s;
		return e - s;
	}
	return -1;
}

static int AI_Hex4(const char* s) {
	int i, v = 0, c;
	for (i = 0; i < 4; i++) {
		c = s[i];
		v <<= 4;
		if (c >= '0' && c <= '9') v |= c - '0';
		else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10;
		else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10;
	}
	return v;
}

/* JSON escapado + UTF-8 -> texto CP437 plano en ai_out */
static int AI_Decode(const char* s, int n) {
	int i = 0, o = 0, cp;
	unsigned char c, d;
	while (i < n && o < AI_OUT_SIZE - 1) {
		c = (unsigned char)s[i++];
		if (c == '\\' && i < n) {
			d = (unsigned char)s[i++];
			if (d == 'n')      c = '\n';
			else if (d == 't') c = ' ';
			else if (d == 'u' && i + 4 <= n) {
				cp = AI_Hex4(s + i); i += 4;
				ai_out[o++] = AI_ToCP437(cp);
				continue;
			} else c = d;
		} else if (c >= 0xC0) {
			if (c < 0xE0 && i < n) {
				cp = ((c & 0x1F) << 6) | (s[i] & 0x3F); i += 1;
			} else if (c < 0xF0 && i + 1 < n) {
				cp = ((c & 0x0F) << 12) | ((s[i] & 0x3F) << 6) | (s[i + 1] & 0x3F); i += 2;
			} else { i += 3; continue; } /* emojis: se saltan */
			ai_out[o++] = AI_ToCP437(cp);
			continue;
		} else if (c >= 0x80) continue;
		if (c == '&') c = '+';
		if (c < 32 && c != '\n') c = ' ';
		ai_out[o++] = (char)c;
	}
	return o;
}

static void AI_EmitLine(const char* buf, int len, cc_bool* first) {
	cc_string out; char outBuf[STRING_SIZE];
	if (!len) return;
	String_InitArray(out, outBuf);
	String_AppendConst(&out, *first ? "&b[IA] &f" : "&f");
	String_AppendAll(&out, buf, len);
	Chat_Add(&out);
	*first = false;
}

static void AI_Print(const char* text, int n) {
	char line[STRING_SIZE];
	int len = 0, i, sp, rest;
	cc_bool first = true;
	for (i = 0; i < n; i++) {
		if (text[i] == '\n') { AI_EmitLine(line, len, &first); len = 0; continue; }
		if (len >= AI_LINE_MAX) {
			for (sp = len - 1; sp > 0 && line[sp] != ' '; sp--) { }
			if (sp > 0) {
				AI_EmitLine(line, sp, &first);
				rest = len - sp - 1;
				memmove(line, line + sp + 1, rest);
				len = rest;
			} else { AI_EmitLine(line, len, &first); len = 0; }
		}
		line[len++] = text[i];
	}
	AI_EmitLine(line, len, &first);
}

static void AI_Tick(struct ScheduledTask* task) {
	struct HttpRequest item;
	cc_string msg; char msgBuf[STRING_SIZE];
	int start, n, outLen;

	if (!ai_reqID) return;
	if (!Http_GetResult(ai_reqID, &item)) return;
	ai_reqID = 0;

	String_InitArray(msg, msgBuf);
	if (item.result) {
		String_Format1(&msg, "&cError de red de la IA (%h)", &item.result);
	} else if (item.statusCode != 200) {
		String_Format1(&msg, "&cLa IA respondio con error HTTP %i", &item.statusCode);
	} else {
		n = item.data ? AI_FindContent((const char*)item.data, (int)item.size, &start) : -1;
		if (n < 0) {
			String_AppendConst(&msg, "&cRespuesta de la IA ilegible");
		} else {
			AI_PushRaw(true, (const char*)item.data + start, n);
			outLen = AI_Decode((const char*)item.data + start, n);
			AI_Print(ai_out, outLen);
			HttpRequest_Free(&item);
			return;
		}
	}
	AI_PopLast(); /* la pregunta fallida no queda en la memoria */
	HttpRequest_Free(&item);
	Chat_Add(&msg);
}

static void AICommand_Execute(const cc_string* args, int argsCount) {
	static const cc_string url = String_FromConst(AI_URL);
	cc_string tmp;
	const char* key;
	int len;

	if (!args->length) { Chat_AddRaw("&eUso: /client ia <pregunta>  |  /client ia reset"); return; }
	if (String_CaselessEqualsConst(args, "reset")) {
		ai_head = 0; ai_count = 0; Options_Reload(); AI_LoadSystemPrompt();
		Chat_AddRaw("&eMemoria borrada y prompt recargado de options.txt.");
		return;
	}
	if (ai_reqID) { Chat_AddRaw("&cEspera, la IA todavia esta respondiendo."); return; }

	key = getenv("GROQ_API_KEY");
	if (!key || !key[0]) { Chat_AddRaw("&cFalta la variable de entorno GROQ_API_KEY."); return; }

	AI_LoadSystemPrompt();

	tmp = String_Init(ai_tmp, 0, (int)sizeof(ai_tmp));
	AI_Escape(&tmp, args);
	AI_PushRaw(false, ai_tmp, tmp.length);

	len = AI_BuildBody();
	ai_reqID = Http_AsyncPostData(&url, 0, ai_body, len, NULL);

	if (!ai_taskAdded) { ScheduledTask_Add(0.25, AI_Tick); ai_taskAdded = true; }
	Chat_AddRaw("&7Pensando...");
}

static struct ChatCommand AICommand = {
	"IA", AICommand_Execute, COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client ia [pregunta]",
		"&eHace una pregunta al asistente de IA (Groq).",
		"&e/client ia reset: borra su memoria (50 mensajes)."
	}
};

void AIChat_Register(void) { Commands_Register(&AICommand); }
